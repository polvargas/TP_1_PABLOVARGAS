package ar.org.centros8.java.curso.trabajo_practico_1.entidades.cuentas;

import ar.org.centros8.java.curso.trabajo_practico_1.entidades.clientes.ClienteEmpresa;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class CuentaConvertibilidad extends CuentaCorriente {
    private double saldoEnDolares;
    private double precioDolar;

    public CuentaConvertibilidad(int nroDeCuenta, ClienteEmpresa clienteAsociado, double giroEnDescubierto) {
        super(nroDeCuenta, clienteAsociado, giroEnDescubierto);
        this.saldoEnDolares = 0.0;
        this.precioDolar = 1400.00;
    }

  public double convertirADolares(double monto) {

        if (monto <= 0) {
            System.out.println("El monto debe ser mayor a 0");
            return saldoEnDolares;
        }

        if (monto <= getSaldo()) {

            System.out.println("Operacion realizada con exito");

            setSaldo(getSaldo() - monto);

            saldoEnDolares =
                    Math.round((saldoEnDolares + (monto / precioDolar)) * 100.0) / 100.0;

            return saldoEnDolares;

        } else {

            System.out.println("Saldo en pesos insuficiente para realizar la operacion");

            return saldoEnDolares;
        }
    }

    
    public double convertirAPesos(double monto) {

        if (monto <= 0) {
            System.out.println("El monto debe ser mayor a 0");
            return getSaldo();
        }

        if (monto <= saldoEnDolares) {

            saldoEnDolares = saldoEnDolares - monto;

            setSaldo(getSaldo() + (monto * precioDolar));

            return getSaldo();

        } else {

            System.out.println("Saldo en dolares insuficiente para realizar la operacion");

            return getSaldo();
        }
    }

    public void depositarDolares(double monto) {

        if (monto <= 0) {
            System.out.println("El monto a depositar debe ser mayor a 0");
            return;
        }

        saldoEnDolares = saldoEnDolares + monto;
    }

    public void extraerDolares(double monto) {

        if (monto <= 0) {
            System.out.println("El monto a extraer debe ser mayor a 0");
            return;
        }

        if (saldoEnDolares >= monto) {

            saldoEnDolares = saldoEnDolares - monto;

        } else {

            System.out.println("Saldo en dolares insuficiente");
        }
    }
}
